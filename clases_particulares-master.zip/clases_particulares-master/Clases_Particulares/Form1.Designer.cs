﻿namespace Clases_Particulares
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.annadir_nino = new System.Windows.Forms.Button();
            this.precio_hora = new System.Windows.Forms.NumericUpDown();
            this.hora_recibidas = new System.Windows.Forms.NumericUpDown();
            this.label1 = new System.Windows.Forms.Label();
            this.listView1 = new System.Windows.Forms.ListView();
            this.Alumno = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.Precio = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.Horas = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.Total = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.Annadir_horas = new System.Windows.Forms.Button();
            this.Paid = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.precio_hora)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.hora_recibidas)).BeginInit();
            this.SuspendLayout();
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(12, 29);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(100, 20);
            this.textBox1.TabIndex = 0;
            // 
            // annadir_nino
            // 
            this.annadir_nino.Enabled = false;
            this.annadir_nino.Location = new System.Drawing.Point(240, 21);
            this.annadir_nino.Name = "annadir_nino";
            this.annadir_nino.Size = new System.Drawing.Size(75, 34);
            this.annadir_nino.TabIndex = 1;
            this.annadir_nino.Text = "Añadir Alumnos";
            this.annadir_nino.UseVisualStyleBackColor = true;
            this.annadir_nino.Click += new System.EventHandler(this.annadir_Click);
            // 
            // precio_hora
            // 
            this.precio_hora.DecimalPlaces = 1;
            this.precio_hora.Location = new System.Drawing.Point(147, 29);
            this.precio_hora.Name = "precio_hora";
            this.precio_hora.Size = new System.Drawing.Size(67, 20);
            this.precio_hora.TabIndex = 2;
            this.precio_hora.ValueChanged += new System.EventHandler(this.precio_hora_ValueChanged);
            // 
            // hora_recibidas
            // 
            this.hora_recibidas.DecimalPlaces = 1;
            this.hora_recibidas.Location = new System.Drawing.Point(12, 95);
            this.hora_recibidas.Name = "hora_recibidas";
            this.hora_recibidas.Size = new System.Drawing.Size(67, 20);
            this.hora_recibidas.TabIndex = 3;
            this.hora_recibidas.ValueChanged += new System.EventHandler(this.hora_recibidas_ValueChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(44, 13);
            this.label1.TabIndex = 4;
            this.label1.Text = "Nombre";
            // 
            // listView1
            // 
            this.listView1.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.Alumno,
            this.Precio,
            this.Horas,
            this.Total});
            this.listView1.FullRowSelect = true;
            this.listView1.Location = new System.Drawing.Point(15, 146);
            this.listView1.MultiSelect = false;
            this.listView1.Name = "listView1";
            this.listView1.Size = new System.Drawing.Size(304, 144);
            this.listView1.TabIndex = 7;
            this.listView1.UseCompatibleStateImageBehavior = false;
            this.listView1.View = System.Windows.Forms.View.Details;
            this.listView1.SelectedIndexChanged += new System.EventHandler(this.listView1_SelectedIndexChanged);
            // 
            // Alumno
            // 
            this.Alumno.Text = "Alumnos";
            // 
            // Precio
            // 
            this.Precio.Text = "Precio";
            // 
            // Horas
            // 
            this.Horas.Text = "Horas";
            // 
            // Total
            // 
            this.Total.Text = "Total";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(144, 9);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(65, 13);
            this.label2.TabIndex = 8;
            this.label2.Text = "Precio/Hora";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(12, 79);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(35, 13);
            this.label3.TabIndex = 9;
            this.label3.Text = "Horas";
            // 
            // Annadir_horas
            // 
            this.Annadir_horas.Enabled = false;
            this.Annadir_horas.Location = new System.Drawing.Point(240, 81);
            this.Annadir_horas.Name = "Annadir_horas";
            this.Annadir_horas.Size = new System.Drawing.Size(79, 34);
            this.Annadir_horas.TabIndex = 10;
            this.Annadir_horas.Text = "Añadir Horas";
            this.Annadir_horas.UseVisualStyleBackColor = true;
            this.Annadir_horas.Click += new System.EventHandler(this.Annadir_horas_Click);
            // 
            // Paid
            // 
            this.Paid.Location = new System.Drawing.Point(240, 296);
            this.Paid.Name = "Paid";
            this.Paid.Size = new System.Drawing.Size(79, 34);
            this.Paid.TabIndex = 11;
            this.Paid.Text = "PAGADO";
            this.Paid.UseVisualStyleBackColor = true;
            this.Paid.Click += new System.EventHandler(this.Paid_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.ClientSize = new System.Drawing.Size(337, 356);
            this.Controls.Add(this.Paid);
            this.Controls.Add(this.Annadir_horas);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.listView1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.hora_recibidas);
            this.Controls.Add(this.precio_hora);
            this.Controls.Add(this.annadir_nino);
            this.Controls.Add(this.textBox1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form1";
            this.Text = "Clases Particulares";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form1_FormClosing);
            ((System.ComponentModel.ISupportInitialize)(this.precio_hora)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.hora_recibidas)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Button annadir_nino;
        private System.Windows.Forms.NumericUpDown precio_hora;
        private System.Windows.Forms.NumericUpDown hora_recibidas;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ListView listView1;
        private System.Windows.Forms.ColumnHeader Alumno;
        private System.Windows.Forms.ColumnHeader Precio;
        private System.Windows.Forms.ColumnHeader Horas;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button Annadir_horas;
        private System.Windows.Forms.ColumnHeader Total;
        private System.Windows.Forms.Button Paid;
    }
}

