﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Clases_Particulares
{
    public partial class Form1 : Form
    {
        List<string> datos_ninos = new List<string>();
        public Form1()
        {
            InitializeComponent();
            ActualizarLista();
        }
        public void ActualizarLista()
        {
            StreamReader sr = new StreamReader("Clases.txt");
            datos_ninos.Clear();
            while (!sr.EndOfStream)
            {
                datos_ninos.Add(sr.ReadLine());
            }
           if(datos_ninos.Count != 0)
            {
                Annadir_listView();
            }
            sr.Close();
        }
        public void Actualizar_ListView()
        {
            listView1.Items.Clear();
            string[] alumnos_string = new string[3];
            for (int i = 0; i < datos_ninos.Count; i++)
            {
                alumnos_string = datos_ninos[i].Split('/');
                listView1.Items.Add(alumnos_string[0]);
                listView1.Items[i].SubItems.Add(alumnos_string[1]);
                listView1.Items[i].SubItems.Add(alumnos_string[2]);
                listView1.Items[i].SubItems.Add(alumnos_string[3]);

            }
        }
        public void Annadir_listView ()
        {
            listView1.Items.Clear();
            string[] alumnos_string = new string[3];
            
            for (int i = 0; i < datos_ninos.Count; i++)
            {
                alumnos_string = datos_ninos[i].Split('/');
                listView1.Items.Add(alumnos_string[0]);
                listView1.Items[i].SubItems.Add(alumnos_string[1]);
                listView1.Items[i].SubItems.Add(alumnos_string[2]);
                listView1.Items[i].SubItems.Add(alumnos_string[3]);

            }
            
        }
        private void annadir_Click(object sender, EventArgs e)
        {


            //StreamWriter sw = new StreamWriter("Clases.txt");
            //for (int i = 0; i < datos_ninos.Count; i++)
            //{
            //    sw.WriteLine(datos_ninos[i]);
            //}
            if(textBox1.Text == "")
            {
                MessageBox.Show("El nombre introducido no es válido", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                datos_ninos.Add(textBox1.Text + "/" + precio_hora.Value + "/" + hora_recibidas.Value + "/" + (precio_hora.Value * hora_recibidas.Value));
                Actualizar_ListView();
                textBox1.Text = "";
                precio_hora.Value = 0;
            }
           
            //sw.Close();
            //ActualizarLista();
        }

        private void Annadir_horas_Click(object sender, EventArgs e)
        {
            if(listView1.SelectedIndices.Count != 0)
            {
                string h = listView1.Items[listView1.SelectedItems[0].Index].SubItems[2].Text;
                decimal horas = decimal.Parse(h);
                horas = horas + decimal.Parse(hora_recibidas.Value.ToString());
                listView1.Items[listView1.SelectedItems[0].Index].SubItems[2].Text = horas.ToString();
                decimal ganancia = (horas * decimal.Parse(listView1.SelectedItems[0].SubItems[1].Text));
                datos_ninos.RemoveAt(listView1.SelectedItems[0].Index);
                datos_ninos.Insert(listView1.SelectedItems[0].Index, listView1.SelectedItems[0].SubItems[0].Text + "/" 
                + listView1.SelectedItems[0].SubItems[1].Text + "/" + listView1.SelectedItems[0].SubItems[2].Text + "/" + ganancia);
                hora_recibidas.Value = 0;

                //ActualizarLista();
                Actualizar_ListView();
            }
            else
            {
                MessageBox.Show("No se ha seleccionado a ningún alumno", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            StreamWriter sw = new StreamWriter("Clases.txt");
            string a = "";
            for (int i = 0; i < datos_ninos.Count; i++)
            {

                a = (listView1.Items[i].SubItems[0].Text);
                a = a + "/" + (listView1.Items[i].SubItems[1].Text);
                a = a + "/" + (listView1.Items[i].SubItems[2].Text);
                a = a + "/" + (double.Parse(listView1.Items[i].SubItems[1].Text) * double.Parse(listView1.Items[i].SubItems[2].Text));
                sw.WriteLine(a);
            }
            sw.Close();
        }

        private void hora_recibidas_ValueChanged(object sender, EventArgs e)
        {
           //hacer que no se pueda usar el boton a no ser que el valor cambie
            if(hora_recibidas.Value != 0)
            {
                Annadir_horas.Enabled = true;
            }
            else
            {
                Annadir_horas.Enabled = false;
            }
        }

        private void precio_hora_ValueChanged(object sender, EventArgs e)
        {
            if(precio_hora.Value != 0 )
            {
                annadir_nino.Enabled = true;
            }
            else
            {
                annadir_nino.Enabled = false;
            }
        }

        private void listView1_SelectedIndexChanged(object sender, EventArgs e)
        {
           
        }

        private void Paid_Click(object sender, EventArgs e)
        {
            if (listView1.SelectedIndices.Count != 0)
            {
                datos_ninos.RemoveAt(listView1.SelectedItems[0].Index);

                datos_ninos.Insert(listView1.SelectedItems[0].Index, listView1.SelectedItems[0].SubItems[0].Text + "/"
                + listView1.SelectedItems[0].SubItems[1].Text + "/" + "0" + "/" + "0");
                Actualizar_ListView();
            }
            else
            {
                MessageBox.Show("No se ha seleccionado a ningún alumno", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
